package com.example.qazanamaz

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val teal = Color.rgb(8, 137, 151)
    private val darkTeal = Color.rgb(15, 78, 86)
    private val pale = Color.rgb(232, 248, 248)
    private val prefs by lazy { getSharedPreferences("qaza_data", Context.MODE_PRIVATE) }

    private val prayers = linkedMapOf(
        "morning" to "نماز صبح",
        "noon" to "نماز ظهر",
        "afternoon" to "نماز عصر",
        "maghrib" to "نماز مغرب",
        "isha" to "نماز عشا"
    )

    private val groups = linkedMapOf(
        "morning" to listOf("morning"),
        "noon_asr" to listOf("noon", "afternoon"),
        "maghrib_isha" to listOf("maghrib", "isha")
    )

    private var lastKey = ""
    private var lastRemaining = 0
    private var lastCompleted = 0
    private var hasUndo = false
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = darkTeal
        window.navigationBarColor = darkTeal
        showHome()
    }

    private fun remaining(key: String) = prefs.getInt("remaining_$key", 0)
    private fun completed(key: String) = prefs.getInt("completed_$key", 0)
    private fun setRemaining(key: String, value: Int) = prefs.edit().putInt("remaining_$key", value).apply()
    private fun setCompleted(key: String, value: Int) = prefs.edit().putInt("completed_$key", value).apply()

    private fun totalRemaining() = prayers.keys.sumOf { remaining(it) }
    private fun totalCompleted() = prayers.keys.sumOf { completed(it) }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun makeBase(title: String, subtitle: String? = null): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pale)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(12), dp(18), dp(18))
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(22), dp(14), dp(22))
            setBackgroundColor(teal)
        }
        header.addView(text(title, 25, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        if (subtitle != null) {
            header.addView(text(subtitle, 14, Color.WHITE).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            })
        }
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = dp(16)
        root.addView(header, params)
        return root
    }

    private fun text(value: String, size: Int, color: Int = darkTeal, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            gravity = Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_RTL
        }
    }

    private fun button(label: String, action: () -> Unit, filled: Boolean = true): Button {
        return Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(if (filled) Color.WHITE else teal)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(if (filled) teal else Color.rgb(218, 242, 243)))
            setOnClickListener { action() }
        }
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(Color.WHITE)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
    }

    private fun addCard(view: View) {
        val p = LinearLayout.LayoutParams(-1, -2)
        p.bottomMargin = dp(12)
        root.addView(view, p)
    }

    private fun showHome() {
        makeBase("قضای نماز", "قدم‌به‌قدم تا جبران")

        val stats = card()
        stats.addView(text("گزارش کلی", 18, darkTeal, true))
        stats.addView(text("نمازهای باقی‌مانده: ${totalRemaining()}", 17, teal, true).apply {
            setPadding(0, dp(10), 0, dp(5))
        })
        stats.addView(text("نمازهای ثبت‌شده: ${totalCompleted()}", 15))
        addCard(stats)

        addGroupCard("نماز صبح", listOf("morning"))
        addGroupCard("نماز ظهر و عصر", listOf("noon", "afternoon"))
        addGroupCard("نماز مغرب و عشا", listOf("maghrib", "isha"))

        addCard(card().apply {
            addView(button("تنظیم تعداد اولیه", { showSettings() }))
            addView(button("بازگرداندن آخرین ثبت", { undo() }, false).apply {
                setPadding(0, dp(5), 0, 0)
            })
        })
    }

    private fun addGroupCard(title: String, keys: List<String>) {
        val c = card()
        c.addView(text(title, 19, darkTeal, true))
        keys.forEach { key ->
            c.addView(text("${prayers[key]}: ${remaining(key)} نماز باقی‌مانده", 15).apply {
                setPadding(0, dp(7), 0, dp(2))
            })
        }
        c.addView(button("ورود به این بخش", {
            showGroup(title, keys)
        }).apply { setPadding(0, dp(5), 0, 0) })
        addCard(c)
    }

    private fun showGroup(title: String, keys: List<String>) {
        makeBase(title, "برای ثبت، نماز خوانده‌شده را انتخاب کن")
        keys.forEach { key ->
            val c = card()
            c.addView(text(prayers[key] ?: "", 19, darkTeal, true))
            c.addView(text("${remaining(key)} نماز باقی‌مانده", 25, teal, true).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(14), 0, dp(14))
            })
            c.addView(button("✓  ${prayers[key]} را خواندم", {
                registerPrayer(key)
            }))
            addCard(c)
        }
        addCard(card().apply {
            addView(button("بازگشت به صفحه اصلی", { showHome() }, false))
            addView(button("بازگرداندن آخرین ثبت", { undo() }, false))
        })
    }

    private fun registerPrayer(key: String) {
        if (remaining(key) <= 0) {
            AlertDialog.Builder(this)
                .setTitle("تعداد به صفر رسیده")
                .setMessage("برای این نماز، تعداد باقی‌مانده صفر است. ابتدا تعداد اولیه را در تنظیمات اصلاح کن.")
                .setPositiveButton("متوجه شدم", null)
                .show()
            return
        }
        lastKey = key
        lastRemaining = remaining(key)
        lastCompleted = completed(key)
        hasUndo = true
        setRemaining(key, lastRemaining - 1)
        setCompleted(key, lastCompleted + 1)
        Toast.makeText(this, "ثبت شد: ${prayers[key]}", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun undo() {
        if (!hasUndo) {
            Toast.makeText(this, "ثبت قبلی برای بازگردانی وجود ندارد.", Toast.LENGTH_SHORT).show()
            return
        }
        setRemaining(lastKey, lastRemaining)
        setCompleted(lastKey, lastCompleted)
        hasUndo = false
        Toast.makeText(this, "آخرین ثبت بازگردانده شد.", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun showSettings() {
        makeBase("تنظیم تعداد اولیه", "برای هر نماز تعداد جداگانه وارد کن")
        val fields = linkedMapOf<String, EditText>()
        prayers.forEach { (key, name) ->
            val c = card()
            c.addView(text(name, 17, darkTeal, true))
            val input = EditText(this).apply {
                inputType = android.text.InputType.TYPE_CLASS_NUMBER
                setSingleLine(true)
                hint = "تعداد باقی‌مانده"
                setText(remaining(key).toString())
                textSize = 17f
            }
            c.addView(input)
            fields[key] = input
            addCard(c)
        }

        addCard(card().apply {
            addView(button("ذخیره تعدادها", {
                val values = mutableMapOf<String, Int>()
                for ((key, input) in fields) {
                    val raw = input.text.toString().trim()
                    val value = raw.toLongOrNull()
                    if (value == null || value < 0 || value > Int.MAX_VALUE) {
                        input.error = "یک عدد صحیح نامنفی وارد کن"
                        return@button
                    }
                    values[key] = value.toInt()
                }
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("تأیید تغییرات")
                    .setMessage("تعدادهای فعلی جایگزین می‌شوند و آمار ثبت‌شده از صفر شروع می‌شود. ادامه می‌دهی؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("تأیید") { _, _ ->
                        values.forEach { (key, value) ->
                            setRemaining(key, value)
                            setCompleted(key, 0)
                        }
                        hasUndo = false
                        showHome()
                    }
                    .show()
            }))
            addView(button("انصراف و بازگشت", { showHome() }, false))
        })
    }
}
